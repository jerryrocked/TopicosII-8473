create database vendedores;
use vendedores;
-- crea tabla de vendedor con valores que serán usados en las tablas
create table if not exists vendedores(
    -- hice nombre primary key para que no se repita el nombre, pero podría usarse una id incremental como la siguiente
    -- id INTEGER PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(30) PRIMARY KEY NOT NULL,
    CanVenCod real,
    CanVenMin real,
    CanVenFor real,
    ComVenCod real,
    ComVenMin real,
    ComVenFor real,
    TotalVentas real,
    Mayor text,
    TotalComision real,
    GananciaCod real,
    GananciaMin real,
    GananciaFor real
);
