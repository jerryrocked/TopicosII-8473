<?php
    function conectar_BaseDeDatos_Juegos(){
      $servername = "localhost";
      $username = "root";
      $password = "";
      $dbname = "juegos";
      $conn = new mysqli($servername, $username, $password, $dbname);
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }  return $conn;
    }
    // funcion para conectar con la base de datos de vendedor
    function conectar_BaseDeDatos_Vendedor(){
      $servername = "localhost";
      $username = "root";
      $password = "";
      $dbname = "vendedores";
      $conn = new mysqli($servername, $username, $password, $dbname);
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }  return $conn;
    }

    // funciones para alimentar tabla
    function juegoGanoMayorComision($canVenCod,$canVenMin,$canVenFor) //Funcion para mostrar el juego más vendido, recibe la cantidad de ventas de cada juego
    {
      $canVenCod = $canVenCod;
      $canVenMin = $canVenMin;
      $canVenFor = $canVenFor;
      $juegoMasVendido = "";

      //calcula cual es mayor y cambiar juegoMasVendido por el nombre del juego que mas se vendio
      if ($canVenCod > $canVenMin && $canVenCod > $canVenFor) {
        $juegoMasVendido = "cod";
        $juegoMasVendidoN = 1;
      } elseif ($canVenMin > $canVenCod && $canVenMin > $canVenFor) {
        $juegoMasVendido = "min";
        $juegoMasVendidoN = 2;
      } elseif ($canVenFor > $canVenCod && $canVenFor > $canVenMin) {
        $juegoMasVendido = "for";
        $juegoMasVendidoN = 3;
      }
      // return $juegoMasVendidoN; por si se requiere un codigo para el juego mas vendido
      return $juegoMasVendido;
    }

    //funcion que recibe $_SESSION['persona'] y devuelve el nombre de la persona con mayores ventas
    function vendedorMayorVentas($persona)
    {
      //recorrer el array de personas
      foreach ($persona as $key => $value) {
        if (isset($mayorTotalVentas)) {
          if ($value['TotalVentas'] > $mayorTotalVentas) { //si el total de ventas es mayor que el mayorTotalVentas
            $mayorTotalVentas = $value['TotalVentas']; //guardar el total de ventas en mayorTotalVentas
            $VendedorMayorVentas = $value['Nom']; //guardar el nombre del vendedor en VendedorMayorVentas
          }
        } else {
          $mayorTotalVentas = $value['TotalVentas'];
          $VendedorMayorVentas = $value['Nom'];
        }
      }
      return $VendedorMayorVentas; //devolver el nombre del vendedor con mayor ventas
    }

    //funcion que recibe $_SESSION['persona'] y devuelve el vendedor con mayores comisiones en base a las ventas
    function vendedorMayorComision($persona)
    {
      //recorrer el array de personas
      foreach ($persona as $key => $value) {
        //comparar nombre de cada persona para buscar el que tenga un mayor valor en TotalVentas
        if (isset($mayorTotalVentas)) {
          if ($value["TotalVentas"] > $mayorTotalVentas2) {
            $mayorTotalVentas2 = $value['TotalVentas'];
            $vendedorMayorComision = $value["TotalComision"];
          }
        } else { // si no hay ningun valor en mayorTotalVentas se guarda el valor de la primera persona
          $mayorTotalVentas2 = $value['TotalVentas'];
          $vendedorMayorComision = $value["TotalComision"];
        }
      }
      return $vendedorMayorComision;
    }
    //funcion que recibe $_SESSION['persona'] y devuelve vendedor mayor comision
    function vendedorMayorComisionVentas($persona)
    {
      //recorrer el array de personas
      foreach ($persona as $key => $value) {
        //comparar nombre de cada persona para buscar el que tenga un mayor valor en TotalVentas
        if (isset($mayorTotalVentas)) {
          if ($value["TotalComision"] > $mayorTotalComision) {
            $mayorTotalComision = $value['TotalComision'];
            $VendedorMayorVentas = $value['Nom'];
          }
        } else { // si no hay ningun valor en mayorTotalVentas se guarda el valor de la primera persona
          $mayorTotalComision = $value['TotalComision'];
          $VendedorMayorVentas = $value['Nom'];
        }
      }
      return $VendedorMayorVentas;
    }
?>