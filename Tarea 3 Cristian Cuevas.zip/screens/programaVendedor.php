<?php @session_start();?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GameMania tu nuevo Hogar</title>
    <link rel="stylesheet" href="../styles/styles.css">
    <!-- fuente Roboto de Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?
        family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="../resources/images/logos/logoControl.png">
</head>
<body class="bodyPHP">
  <div class="navbar" style="backdrop-filter: blur(6px); margin: 0px 0px; padding: 0px 20px;">
    <img class="logo_h1_maxscreen" src="../resources/images/logos/logoControl.png">
    <!-- para despues centrar el icono en el celular -->
    <div class="center">
        <img class="logo_h1_mobile" src="../resources/images/logos/logoControl.png">
        <h1 id="h1_nav">GameMania</h1>
    </div>
    <nav id="nav">
        <ul>
            <li><a href="../index.php">Inicio</a></li>
        </ul>
    </nav>
  </div>
  <div class="containerForm">
    <?php 
    include("funciones.php"); //incluimos el archivo de funciones para poder utilizar las funciones en la pagina actual
    // el modelo CRUD es usado para crear, leer, actualizar y eliminar los registros de la base de datos
    // se crea una variable que contiene la conexion a la base de datos
    $conn = conectar_BaseDeDatos_Juegos();
    $connVendedor = conectar_BaseDeDatos_Vendedor();
    ?>
    <!-- div de Juegos y sus Imagenes -->
    <div class="simetriBlur">
        <h3 class="subTitle">Juegos Disponibles</h3>
        <div class="centeredImages">
          <div class="margins">
            <img class="marginsTopBottom" src="../resources/images/callofdutyCard.jpg" alt="cod" width="100" height="100">
            <h4>Valor: $34500</h4>
            <h4>Comisión: 6%</h4>
          </div>
          <div class="margins">
            <img class="marginsTopBottom" src="../resources/images/minecraftCard.jpg" alt="min" width="100" height="100">
            <h4>Valor: $8800</h4>
            <h4>Comisión: 4%</h4>
          </div>
          <div class="margins">
            <img class="marginsTopBottom" src="../resources/images/fortniteCard.jpg" alt="for" width="100" height="100">
            <h4>Valor: $58200</h4>
            <h4>Comisión: 9%</h4>
          </div>
        </div>
      </div>
      <!-- Inicio del Formulario y su Titulo -->
      <br>
      <div class="marg"><h3 class="brblank">Registrar Vendedor y Ventas</h3></div>
      <div class="centerAll">
        <form method="post">
          <h4 class="brblank">Nombre</h4>
          <input class="inputsPHP" type="text" id="Nom" Name="Nom">
          <h4 class="brblank">Call of duty</h4>
          <input class="inputsPHP" type="text" id="CanVenCod" Name="CanVenCod">
          <h4 class="brblank">Minecraft</h4>
          <input class="inputsPHP" type="text" id="CanVenMin" Name="CanVenMin">
          <h4 class="brblank">Fortnite</h4>
          <input class="inputsPHP" type="text" id="CanVenFor" Name="CanVenFor">
          <br>
          <br>
          <div class="btnAllign">
            <button class="btnPHP" type="submit" name="insertar"> Insertar<br>Datos</button>
            <button class="btnPHP" type="submit" name="mostrarTabla"> Mostrar Tabla</button>
            <button class="btnPHP" type="submit" name="mostrarTodoEnTexto"> Mostrar modo texto </button>
          </div>
          <br>
          <br>
          <button class="btnPHP2" type="submit" name="mostrarMayorComision"> Mostrar Vendedor con Mayor Comisión </button>
          <br>
          <br>
        </form>
      </div>
    <?php
      if (!isset($_SESSION['persona'])){
        $_SESSION['persona']=array();
      }
      if (isset($_POST['insertar'])) {
        $nom= $_POST['Nom'];
        $canVenCod= $_POST['CanVenCod'];
        $canVenMin= $_POST['CanVenMin'];
        $canVenFor= $_POST['CanVenFor'];
        if (empty($nom)||empty($canVenCod)||empty($canVenMin)||empty($canVenFor)) { //si algun campo esta vacio
          echo "Rellena todos los valores";
          //alert dialog en formulario
          echo "<script>alert('Rellena todos los valores');</script>"; //alerta
          //if $nom no puede contener numeros ni caracteres especiales
        } else if (!preg_match("/^[a-zA-Z ]*$/",$nom)) { //si $nom no puede contener numeros ni caracteres especiales
          echo "<script>alert('El valor Nombre no puede contener caracteres ni numeros');</script>"; //alerta
        } else if (!preg_match("/^[0-9]*$/",$canVenCod)||!preg_match("/^[0-9]*$/",$canVenMin)||!preg_match("/^[0-9]*$/",$canVenFor)) { //si $nom no puede contener numeros ni caracteres especiales
          echo "<script>alert('El valor de cada producto no puede contener caracteres especiales ni numeros negativos o decimales');</script>"; //alerta
        } else {
          //array de personas
          $persona = [
            "Nom" => $nom,
            "CanVenCod" => $canVenCod,
            "CanVenMin" => $canVenMin,
            "CanVenFor" => $canVenFor,
            // multiplica valor de canVenCod por 34500 y sacar la comision de venta que es de 6%
            "ComVenCod" => $canVenCod*0.06*34500,
            // guarda en variable la comision ganada de Minecraft que es de 4%
            "ComVenMin" => $canVenMin*0.04*8800,
            // guarda en variable la comision ganada de Fortnite que es de 9%
            "ComVenFor" => $canVenFor*0.09*58200,
            // guarda en variable el que más ventas hizo
            "TotalVentas" => $canVenCod+$canVenMin+$canVenFor,
            // guarda en variable el juego que mas comision gano
            "Mayor" => juegoGanoMayorComision($canVenCod*0.06*34500,$canVenMin*0.04*8800,$canVenFor*0.09*58200),
            // guarda en variable el total de comisiones ganadas
            "TotalComision" => $canVenCod*0.06*34500+$canVenMin*0.04*8800+$canVenFor*0.09*58200,
            // guarda variable de las ganacias por cada juego
            "GananciaCod" => $canVenCod*34500,
            "GananciaMin" => $canVenMin*8800,
            "GananciaFor" => $canVenFor*58200,
          ];
          // seleccionar la base de datos
          $result = $connVendedor->query("USE vendedores");
          // Variables para guardar los datos de la persona
          $nom = $nom;
          $canVenCod = $canVenCod;
          $canVenMin = $canVenMin;
          $canVenFor = $canVenFor;
          $comVenCod = $canVenCod*0.06*34500;
          $comVenMin = $canVenMin*0.04*8800;
          $comVenFor = $canVenFor*0.09*58200;
          $totalVentas = $canVenCod+$canVenMin+$canVenFor;
          $mayor = juegoGanoMayorComision($canVenCod*0.06*34500,$canVenMin*0.04*8800,$canVenFor*0.09*58200);
          $totalComision = $canVenCod*0.06*34500+$canVenMin*0.04*8800+$canVenFor*0.09*58200;
          $gananciaCod = $canVenCod*34500;
          $gananciaMin = $canVenMin*8800;
          $gananciaFor = $canVenFor*58200;
          // inserta datos en la base de datos
          $sql = "INSERT INTO vendedores (nombre, CanVenCod, CanVenMin, CanVenFor, ComVenCod, ComVenMin, ComVenFor, TotalVentas, Mayor, TotalComision, GananciaCod, GananciaMin, GananciaFor)
                  VALUES ('$nom', '$canVenCod', '$canVenMin', '$canVenFor', '$comVenCod', '$comVenMin', '$comVenFor', $totalVentas,
                  '$mayor', '$totalComision', '$gananciaCod' ,'$gananciaMin', '$gananciaFor')";
          // ejecuta la consulta
          $result = $connVendedor->query($sql);
          // si la consulta se ejecuta correctamente
          if ($connVendedor->query($sql) === TRUE) {
            echo "<span style='color:white;'>";
            echo "Nuevo registro creado correctamente: "; //se registra nueva
            echo "</span>";
          } else if ($connVendedor->errno === 1062) { // si el error es de duplicado
            $sql = "UPDATE vendedores SET CanVenCod = '$canVenCod', CanVenMin = '$canVenMin', CanVenFor = '$canVenFor', ComVenCod = '$comVenCod', ComVenMin = '$comVenMin',
              ComVenFor = '$comVenFor', TotalVentas = '$totalVentas', Mayor = '$mayor', TotalComision = '$totalComision', GananciaCod = '$gananciaCod', GananciaMin = '$gananciaMin',
              GananciaFor = '$gananciaFor' WHERE nombre = '$nom'";
            $result = $connVendedor->query($sql);
          } else { // si el error es de otro tipo
            echo "Error if Ln107: " . $sql . "<br>" . $connVendedor->error;
          }
          // abajo hay metodos para editar y eliminar (aún no hacen nada)
          if (isset($_SESSION['persona'][$nom])) { //si ya existe una persona con ese nombre
            echo "<span style='color:yellow;'>";
            echo "Se ha Registrado/Modificado la Persona con el Nombre: ".$nom; //se modifica antigua
            echo "</span>";
          }else{
            echo "<span style='color:white;'>";
            echo "Se ha Registrado/Modificado una persona con Nombre: ".$nom; //se registra nueva
            echo "</span>";
          }
          $_SESSION['persona'][$nom]=$persona; //guardar persona en array de personas
          echo "<br>";
        }
      }
      if (isset($_POST['mostrarTabla'])){
        if (is_countable($_SESSION['persona']===0)){ //si no hay personas
          echo "<p> No hay Personas </p>";
        }else {
          // para ver si hay datos en la base de datos
          $sql = "SELECT * FROM vendedores";
          $result = $connVendedor->query($sql);
          $numero = $result->num_rows;
          // si hay datos
          if ($numero > 0) {
            // form y tabla para mostrar las personas usando la base de datos de personas y checkbox
            echo "<form class='formTab' method='post'>";
            echo "<table class='table_style'>";
            echo "<tr>";
            echo "<th></th>";
            echo "<th class='cell_color'>Nombre</th>";
            echo "<th class='cell_color'>Call of duty</th>";
            echo "<th class='cell_color'>Minecraft</th>";
            echo "<th class='cell_color'>Fortnite</th>";
            echo "<th class='cell_color'>Total Ventas</th>";
            echo "<th class='cell_color'>Comision Call of Duty</th>";
            echo "<th class='cell_color'>Comision Minecraft</th>";
            echo "<th class='cell_color'>Comision Fortnite</th>";
            echo "<th class='cell_color'>Comision Total</th>";
            echo "<th class='cell_color'>Imagen del Juego</th>";
            echo "</tr>";
            // usa base de datos para mostrar todos los datos
            $sql = "SELECT * FROM vendedores";
            $result = $connVendedor->query($sql);
            if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td><input type='checkbox' name='checkbox[]' value='".$row["nombre"]."'></td>";
                echo "<td>".$row["nombre"]."</td>";
                // isset para que no se muestre vacio
                if (isset($row["CanVenCod"])){
                  echo "<td>".$row["CanVenCod"]."</td>";
                }else{
                  echo "<td>0</td>";
                }
                if (isset($row["CanVenMin"])){
                  echo "<td>".$row["CanVenMin"]."</td>";
                }else{
                  echo "<td>0</td>";
                }
                if (isset($row["CanVenFor"])){
                  echo "<td>".$row["CanVenFor"]."</td>";
                }else{
                  echo "<td>0</td>";
                }
                if (isset($row["TotalVentas"])){
                  echo "<td>".$row["TotalVentas"]."</td>";
                }else{
                  echo "<td>0</td>";
                }
                if (isset($row["ComVenCod"])){
                  echo "<td>".$row["ComVenCod"]."</td>";
                }else{
                  echo "<td>0</td>";
                }
                if (isset($row["ComVenMin"])){
                  echo "<td>".$row["ComVenMin"]."</td>";
                }else{
                  echo "<td>0</td>";
                }
                if (isset($row["ComVenFor"])){
                  echo "<td>".$row["ComVenFor"]."</td>";
                }else{
                  echo "<td>0</td>";
                }
                if (isset($row["TotalComision"])){
                  echo "<td>".$row["TotalComision"]."</td>";
                }else{
                  echo "<td>0</td>";
                }
                if ($row['Mayor'] == "cod"){
                  echo "<td><img src='../resources/images/callofdutyCard.jpg' width='100' height='100'></td>";
                }else if ($row['Mayor'] == "min"){
                  echo "<td><img src='../resources/images/minecraftCard.jpg' width='100' height='100'></td>";
                }else if ($row['Mayor'] == "for"){
                  echo "<td><img src='../resources/images/fortniteCard.jpg' width='100' height='100'></td>";
                }
                echo "</tr>";
              }
            } else {
              echo "No hay registros";
            }
            echo "</table>";
            echo "<br>";
            echo "<br>";
            echo "<div class='btnAllign'>";
            echo "<button class='btnForm' type='submit' name='eliminar'> Eliminar Personas </button>";
            echo "<button class='btnPHP' type='submit' name='modificar' style='margin-left:10px;' >Modificar </button>";
            echo "</div>";
            echo "</form>";
            // se usa la base de datos para mostrar datos que se piden en texto
            $sql = "SELECT * FROM vendedores WHERE TotalComision = (SELECT MAX(TotalComision) FROM vendedores)";
            $result = $connVendedor->query($sql);
            if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
                echo "<h4 style='font-size: 20px;'> El vendedor que generó más ventas es: ".$row["nombre"]."</h4>"; //muestra el nombre del vendedor seleccionado
                echo "<h4 style='font-size: 20px;'> Ganando una comisión total de: ".$row["TotalComision"]."</h4>"; //muestra la comision gananada por el vendedor seleccionado
              }
            } else {
              echo "<h4 style='font-size: 20px;'> No hay vendedores con ventas </h4>"; //si no hay vendedores con ventas muestra este mensaje
            }
          } else {
            echo "<h4 style='font-size: 20px;'> No hay vendedores en la base de datos </h4>";
          }
        }
      }
      //si se presiona el boton mostrar vendedor mayor comision
      if (isset($_POST['mostrarMayorComision'])) {
        if (is_countable($_SESSION['persona']===0)){
          echo "<p> No hay Personas </p>";
        }else {
          // si el return del vendedor no está vacio muestra el echo
          if (vendedorMayorVentas($_SESSION['persona']) != ""){
            // busca en la base de datos el vendedor con el valor más alto de TotalComision
            $sql = "SELECT * FROM vendedores WHERE TotalComision = (SELECT MAX(TotalComision) FROM vendedores)";
            $result = $connVendedor->query($sql);
            if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
                echo "<h4 style='font-size: 25px;'> El vendedor que generó más ventas es: ".$row["nombre"]."</h4>"; //muestra el nombre del vendedor seleccionado
                echo "<h4 style='font-size: 25px;'> Ganando una comisión total de: ".$row["TotalComision"]."</h4>"; //muestra la comision gananada por el vendedor seleccionado
              }
            } else {
              echo "<h4 style='font-size: 25px;'> No hay vendedores con ventas </h4>"; //si no hay vendedores con ventas muestra este mensaje
            }
          }else{
            echo "<h4 style='font-size: 25px;'> No hay vendedores con ventas </h4>"; //si no hay vendedores con ventas muestra este mensaje
          }
        }
      }
      //si se presiona el boton mostrar modo Texto
      if (isset($_POST['mostrarTodoEnTexto'])){
        if (is_countable($_SESSION['persona']===0)){ //si no hay personas
          echo "<p> No hay Personas </p>";
        }else {
          // recorrer la base de datos y mostrar todos los datos en texto
          $sql = "SELECT * FROM vendedores";
          $result = $connVendedor->query($sql);
          if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
              echo "<h5> Nombre del Vendedor: ".$row["nombre"]."</h5>"; //muestra el nombre del vendedor seleccionado

              echo "<h5> Cantidad de Ventas del Call Of Duty: ".$row["CanVenCod"]."</h5>"; //muestra la cantidad de ventas del vendedor seleccionado
              echo "<h5> Precio de Venta: $34500</h5>";
              echo "<h5> Comisión: 6%</h5>";
              echo "<h5> Cantidad Vendida sin comision: ".$row['GananciaCod']."</h5>";
              echo "<h5> Comisión Ganada: ".$row["ComVenCod"]."</h5>";

              echo "<h5> Cantidad de Ventas del Minecraft: ".$row["CanVenMin"]."</h5>"; //muestra la cantidad de ventas del vendedor seleccionado
              echo "<h5> Precio de Venta: $8800</h5>";
              echo "<h5> Comisión: 4%</h5>";
              echo "<h5> Cantidad Vendida sin comision: ".$row['GananciaMin']."</h5>";
              echo "<h5> Comisión Ganada: ".$row['ComVenMin']."</h5>";

              echo "<h5> Cantidad de Ventas del Fortnite: ".$row['CanVenFor']."</h5>";
              echo "<h5> Precio de Venta: $58200</h5>";
              echo "<h5> Comisión: 9%</h5>";
              echo "<h5> Cantidad Vendida sin comision: ".$row['GananciaFor']."</h5>";
              echo "<h5> Comisión Ganada: ".$row['ComVenMin']."</h5>";

              echo "<h5> Total de Ventas: ".$row["TotalVentas"]."</h5>"; //muestra la cantidad de ventas del vendedor seleccionado
              echo "<h5> ------------------------------------- </h5>";
            }
          } else {
            echo "<h4 style='font-size: 20px;'> No hay vendedores en la base de datos </h4>";
          }
        }
      }
      //si se presiona el boton eliminar de la base de datos
      if (isset($_POST['eliminar'])){
        if (is_countable($_SESSION['persona']===0)){ //si no hay personas
          echo "<p> No hay Personas </p>";
        }else {
          // recorrer la base de datos y mostrar todos los datos en texto
          $sql = "SELECT * FROM vendedores";
          $result = $connVendedor->query($sql);
          // elimina de la base de datos el vendedor seleccionado
          if (isset($_POST['checkbox'])){
            $noms = $_POST['checkbox'];
            foreach ($noms as $nombre) {
              $sql = "DELETE FROM vendedores WHERE nombre = '$nombre'";
              $result = $connVendedor->query($sql);
            }
            if ($result) {
              echo "<h4 style='font-size: 20px;'> Vendedor eliminado </h4>";
            } else {
              echo "<h4 style='font-size: 20px;'> No se pudo eliminar el vendedor </h4>";
            }
          } else {
            echo "<h4 style='font-size: 20px;'> No se pudo eliminar el vendedor </h4>";
          }
        }
      }
      // si se presiona modificar tabla y la de la base de datos
      if (isset($_POST['modificar'])){
        if (is_countable($_SESSION['persona']===0)){ //si no hay personas
          echo "<p> No hay Personas </p>";
        }else {
          // si no se selecciona ningun vendedor muestra este mensaje	
          if (!isset($_POST['checkbox'])){
            echo "<h4 style='font-size: 20px;'> No se selecciono ningun vendedor </h4>";
          }
          if (isset($_POST['checkbox'])){
            $noms = $_POST['checkbox'];
            // si el checkbox seleccionó más de uno se muestra un mensaje
            if (count($noms)>1){
              echo "<h4 style='font-size: 20px;'> No se puede modificar mas de 1 vendedor a la vez </h4>";
            }else{
              echo "<form class='formTab' method='post'>";
              echo "<table class='table_style'>";
              echo "<tr>";
              echo "<th class='cell_color'>Nombre</th>";
              echo "<th class='cell_color'>Call of duty</th>";
              echo "<th class='cell_color'>Minecraft</th>";
              echo "<th class='cell_color'>Fortnite</th>";
              echo "<th class='cell_color'>Total Ventas</th>";
              echo "<th class='cell_color'>Comision Call of Duty</th>";
              echo "<th class='cell_color'>Comision Minecraft</th>";
              echo "<th class='cell_color'>Comision Fortnite</th>";
              echo "<th class='cell_color'>Comision Total</th>";
              echo "<th class='cell_color'>Imagen del Juego</th>";
              echo "</tr>";
              foreach ($noms as $nombre) {
                $sql = "SELECT * FROM vendedores WHERE nombre = '$nombre'";
                $result = $connVendedor->query($sql);
              }
              // mostrar datos de result en un tabla
              if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                  echo "<tr>";
                  // echo con input readonly para que no se pueda modificar el nombre que es primary key
                  echo "<td><input class='inputReadOnly' type='text' name='nombre' value='".$row["nombre"]."' readonly></td>";
                  // isset para que no se muestre vacio
                  if (isset($row["CanVenCod"])){
                    echo "<td><input class='inputEdit' type='text' name='CanVenCod' value='".$row["CanVenCod"]."'></td>";
                  }else{
                    echo "<td>0</td>";
                  }
                  if (isset($row["CanVenMin"])){
                    echo "<td><input class='inputEdit' type='text' name='CanVenMin' value='".$row["CanVenMin"]."'></td>";
                  }else{
                    echo "<td>0</td>";
                  }
                  if (isset($row["CanVenFor"])){
                    echo "<td><input class='inputEdit' type='text' name='CanVenFor' value='".$row["CanVenFor"]."'></td>";
                  }else{
                    echo "<td>0</td>";
                  }
                  if (isset($row["TotalVentas"])){
                    echo "<td>".$row["TotalVentas"]."</td>";
                  }else{
                    echo "<td>0</td>";
                  }
                  if (isset($row["ComVenCod"])){
                    echo "<td>".$row["ComVenCod"]."</td>";
                  }else{
                    echo "<td>0</td>";
                  }
                  if (isset($row["ComVenMin"])){
                    echo "<td>".$row["ComVenMin"]."</td>";
                  }else{
                    echo "<td>0</td>";
                  }
                  if (isset($row["ComVenFor"])){
                    echo "<td>".$row["ComVenFor"]."</td>";
                  }else{
                    echo "<td>0</td>";
                  }
                  if (isset($row["TotalComision"])){
                    echo "<td>".$row["TotalComision"]."</td>";
                  }else{
                    echo "<td>0</td>";
                  }
                  if ($row['Mayor'] == "cod"){
                    echo "<td><img src='../resources/images/callofdutyCard.jpg' width='100' height='100'></td>";
                  }else if ($row['Mayor'] == "min"){
                    echo "<td><img src='../resources/images/minecraftCard.jpg' width='100' height='100'></td>";
                  }else if ($row['Mayor'] == "for"){
                    echo "<td><img src='../resources/images/fortniteCard.jpg' width='100' height='100'></td>";
                  }
                  echo "</tr>";

                  echo "</table>";
                  echo "<br>";
                  echo "<br>";
                  echo "<div class='btnAllign'>";
                  echo "<button class='btnPHP' type='submit' name='modificarBaseDeDatos'> Modificar </button>";
                  echo "</div>";
                  echo "</form>";
                }
              } else {
                echo "No hay vendedores";
              }
            }
          }
        }
      }
      // si se hizo click en el button modificarBaseDeDatos
      if (isset($_POST['modificarBaseDeDatos'])){
        // actualizar solo nombre
        if (isset($_POST['nombre'])){
          $nombre = $_POST['nombre']; // solo será usado para buscar el vendedor en la base de datos
          $CanVenCod = $_POST['CanVenCod'];
          $CanVenMin = $_POST['CanVenMin'];
          $CanVenFor = $_POST['CanVenFor'];
          // convierte los valores a los que permite la base de datos
          $CanVenCod = intval($CanVenCod);
          $CanVenMin = intval($CanVenMin);
          $CanVenFor = intval($CanVenFor);
          // Volvemos a calcular el total de ventas
          $comVenCod = $CanVenCod*0.06*34500;
          $comVenMin = $CanVenMin*0.04*8800;
          $comVenFor = $CanVenMin*0.09*58200;
          $totalVentas = $CanVenCod+$CanVenMin+$CanVenFor;
          $mayor = juegoGanoMayorComision($CanVenCod*0.06*34500,$CanVenMin*0.04*8800,$CanVenFor*0.09*58200);
          $totalComision = $CanVenCod*0.06*34500+$CanVenMin*0.04*8800+$CanVenFor*0.09*58200;
          $gananciaCod = $CanVenCod*34500;
          $gananciaMin = $CanVenMin*8800;
          $gananciaFor = $CanVenFor*58200;
          // actualizar la base de datos
          $sql = "UPDATE vendedores SET CanVenCod = '$CanVenCod', CanVenMin = '$CanVenMin', CanVenFor = '$CanVenFor', TotalVentas = '$totalVentas', ComVenCod = '$comVenCod', ComVenMin = '$comVenMin', ComVenFor = '$comVenFor', TotalComision = '$totalComision', Mayor = '$mayor', GananciaCod = '$gananciaCod', GananciaMin = '$gananciaMin', GananciaFor = '$gananciaFor' WHERE nombre = '$nombre'";

          $result = $connVendedor->query($sql);
          if ($result) {
            echo "<h4 style='font-size: 20px;'> Vendedor modificado </h4>";
          } else {
            echo "<h4 style='font-size: 20px;'> No se pudo modificar el vendedor </h4>";
          }
        }
      }      
      ?>
  </div>
</body>
</html>