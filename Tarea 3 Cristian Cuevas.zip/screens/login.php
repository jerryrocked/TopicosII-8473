<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GameMania tu nuevo Hogar</title>
    <link rel="stylesheet" href="../styles/styles.css">
    <!-- fuente Roboto de Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?
        family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="../resources/images/logos/logoControl.png">
</head>
<!-- formulario con usuario, password y un botón de login que envia a programaVendedor.php si la usuario y password es admin -->
<body class="bodyLogin">
    <div class="navbar">
        <img class="logo_h1_maxscreen" src="../resources/images/logos/logoControl.png">
        <!-- para despues centrar el icono en el celular -->
        <div class="center">
            <img class="logo_h1_mobile" src="../resources/images/logos/logoControl.png">
            <h1 id="h1_nav">GameMania</h1>
        </div>
        <nav id="nav">
            <ul>
                <li><a href="../index.php">Inicio</a></li>
                <li><a href="login.php">Iniciar sesion</a></li>
            </ul>
        </nav>
    </div>
    <div class="container">
        <div class="fondoFormLogin">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="h4login">INICIAR SESIÓN</h4>
                            <form class="form-signin" action="programaVendedor.php" method="post">
                                <div class="form-label-group">
                                    <label class="textlogin" for="inputEmail">Usuario</label>
                                    <br>
                                    <input class="inputs" type="text" id="inputEmail" class="form-control" placeholder="Usuario" required autofocus name="usuario">
                                </div>
                                <div class="form-label-group">
                                    <label class="textlogin" for="inputPassword">Contraseña</label>
                                    <br>
                                    <input class="inputs" type="password" id="inputPassword" class="form-control" placeholder="Contraseña" required name="password">
                                </div>
                                <button class="btnLogin" type="submit">Iniciar Sesión</button>
                            </form>
                        </div>
                    </div> 
                </div>
            </div>
        </div>
    </div>
</body>







