<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GameMania tu nuevo Hogar</title>
    <link rel="stylesheet" href="styles/styles.css">
    <!-- fuente Roboto de Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?
        family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="resources/images/logos/logoControl.png">
</head>
<body>
    <!-- Barra de Navegación superior izquierda con links a paginas de esta web -->
    <div class="navbar">
        <img class="logo_h1_maxscreen" src="resources/images/logos/logoControl.png">
        <!-- para despues centrar el icono en el celular -->
        <div class="center">
            <img class="logo_h1_mobile" src="resources/images/logos/logoControl.png">
            <h1 id="h1_nav">GameMania</h1>
        </div>
        <nav id="nav">
            <ul>
                <li><a href="">Inicio</a></li>
                <li><a href="screens/login.php">Iniciar sesion</a></li>
            </ul>
        </nav>
    </div>
    <section class="section_inicio">
        <!-- clase que luego le da el formato a la izquierda, los agrupa -->
        <div class="intro_page">
            <h1 class="indexh1">GameMania</h1>
            <p class="indexp">Es una tienda de videojuegos que vende por excelencia tres grandes titulos de la actualidad, Estos son Call of Duty, Fornite que son Shooters y Minecraft que es un juego de mundo abierto.
            </p>
            <!-- "botón" actualmente contiene un link para pulsar -->
            <div>
              <button class="btn-1" action="programaVendedor.php"><a href="screens/login.php">Inicia sesion!</button>
            </div>
        </div>
    </section>

    <!-- clase image es la "Card" que alberga distintas imagenes de futbolistas -->
    <section class="section_card">
        <div>
            <!-- columna para mantener juntas las "Card" (Imagenes, texto, etc) -->
            <div class="col">
                <h2 class="title-card">Juego Actuales</h2>
                <div class="image_no_up">
                    <h4 id="title_image_card">Call of Duty</h4>
                    <!-- clase que contiene una imagen -->
                    <a href="https://www.callofduty.com/es"><img class="image_img_no_up" src="resources/images/callofdutyCard.jpg" alt="chilecard"></a>
                </div>
                <div class="image_no_up">
                    <h4 id="title_image_card">Fortnite</h4>
                    <!-- clase que contiene una imagen -->
                    <a href="https://www.epicgames.com/fortnite/es-ES/home"><img class="image_img_no_up" src="resources/images/fortniteCard.jpg" alt="chilecard"></a>
                </div>
                <div class="image_no_up">
                    <h4 id="title_image_card">Minecraft</h4>
                    <!-- clase que contiene una imagen -->
                    <a href="https://www.minecraft.net/es-es"><img class="image_img_no_up" src="resources/images/minecraftCard.jpg" alt="chilecard"></a>
                </div>
            </div>
        </div>
    </section>

    <!-- creación del footer -->
    <footer class="footer">
        <h5 id="footer-left">GAMEMANIA 2022</h5>
        <h5 id="footer-right">Copyright@ 2022 GameMania</h5>
    </footer>
</body>

</html>