<?php @session_start();?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GameMania tu nuevo Hogar</title>
    <link rel="stylesheet" href="../styles/styles.css">
    <!-- fuente Roboto de Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?
        family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="../resources/images/logos/logoControl.png">
</head>
<body class="bodyPHP">
  <div class="navbar" style="backdrop-filter: blur(6px);">
    <img class="logo_h1_maxscreen" src="../resources/images/logos/logoControl.png">
    <!-- para despues centrar el icono en el celular -->
    <div class="center">
        <img class="logo_h1_mobile" src="../resources/images/logos/logoControl.png">
        <h1 id="h1_nav">GameMania</h1>
    </div>
    <nav id="nav">
        <ul>
            <li><a href="../index.php">Inicio</a></li>
        </ul>
    </nav>
  </div>
  <div class="containerForm">
    <?php
    include("funciones.php"); //incluimos el archivo de funciones para poder utilizar las funciones en la pagina actual
    ?>

    <?php
      if (!isset($_SESSION['persona'])){
        $_SESSION['persona']=array();
      }
      if (isset($_POST['insertar'])) {
        $nom= $_POST['Nom'];
        $canVenCod= $_POST['CanVenCod'];
        $canVenMin= $_POST['CanVenMin'];
        $canVenFor= $_POST['CanVenFor'];
        if (empty($nom)||empty($canVenCod)||empty($canVenMin)||empty($canVenFor)) { //si algun campo esta vacio
          echo "Rellena todos los valores";
          //alert dialog en formulario
          echo "<script>alert('Rellena todos los valores');</script>"; //alerta
          //if $nom no puede contener numeros ni caracteres especiales
        } else if (!preg_match("/^[a-zA-Z ]*$/",$nom)) { //si $nom no puede contener numeros ni caracteres especiales
          echo "<script>alert('El valor Nombre no puede contener caracteres ni numeros');</script>"; //alerta
        } else if (!preg_match("/^[0-9]*$/",$canVenCod)||!preg_match("/^[0-9]*$/",$canVenMin)||!preg_match("/^[0-9]*$/",$canVenFor)) { //si $nom no puede contener numeros ni caracteres especiales
          echo "<script>alert('El valor de cada producto no puede contener caracteres especiales ni numeros negativos o decimales');</script>"; //alerta
        } else {
          //array de personas
          $persona = array( 
            "Nom" => $nom,
            "CanVenCod" => $canVenCod,
            "CanVenMin" => $canVenMin,
            "CanVenFor" => $canVenFor,
            // multiplica valor de canVenCod por 34500 y sacar la comision de venta que es de 6%
            "ComVenCod" => $canVenCod*0.06*34500,
            // guarda en variable la comision ganada de Minecraft que es de 4%
            "ComVenMin" => $canVenMin*0.04*8800,
            // guarda en variable la comision ganada de Fortnite que es de 9%
            "ComVenFor" => $canVenFor*0.09*58200,
            // guarda en variable el que más ventas hizo
            "TotalVentas" => $canVenCod+$canVenMin+$canVenFor,
            // guarda en variable el juego que mas comision gano
            "Mayor" => juegoGanoMayorComision($canVenCod*0.06*34500,$canVenMin*0.04*8800,$canVenFor*0.09*58200),
            // guarda en variable el total de comisiones ganadas
            "TotalComision" => $canVenCod*0.06*34500+$canVenMin*0.04*8800+$canVenFor*0.09*58200,
            // guarda variable de las ganacias por cada juego
            "GananciaCod" => $canVenCod*34500,
            "GananciaMin" => $canVenMin*8800,
            "GananciaFor" => $canVenFor*58200,
          );
          if (isset($_SESSION['persona'][$nom])) { //si ya existe una persona con ese nombre
            echo "Se ha modificado la Persona con el Nombre: ".$nom; //se modifica
          }else{
            echo "<span style='color:white;'>";
            echo "Se ha registrado una persona con Nombre: ".$nom;
            echo "</span>";
          }
          $_SESSION['persona'][$nom]=$persona; //guardar persona en array de personas
          echo "<br>";
        }
      } else if (isset($_POST['vaciar'])){ //si se pulsa el boton vaciar
        if (!isset($_POST['noms'])){
          echo "No hay personas seleccionadas";
        }else{
          $noms=$_POST['noms'];
          print_r($noms);
          foreach ($_SESSION['persona'] as $key => $value){
            if (in_array($key,$noms)){
              unset($_SESSION['persona'][$key]);
            }
          }
          echo "Persona(s) Borrada(s) ";
        }
      }
      ?>
      <!-- div de Juegos y sus Imagenes -->
      <div class="simetriBlur">
        <h3 class="subTitle">Juegos Disponibles</h3>
        <div class="centeredImages">
          <div class="margins">
            <img class="marginsTopBottom" src="../resources/images/callofdutyCard.jpg" alt="cod" width="100" height="100">
            <h4>Valor: $34500</h4>
            <h4>Comisión: 6%</h4>
          </div>
          <div class="margins">
            <img class="marginsTopBottom" src="../resources/images/minecraftCard.jpg" alt="min" width="100" height="100">
            <h4>Valor: $8800</h4>
            <h4>Comisión: 4%</h4>
          </div>
          <div class="margins">
            <img class="marginsTopBottom" src="../resources/images/fortniteCard.jpg" alt="for" width="100" height="100">
            <h4>Valor: $58200</h4>
            <h4>Comisión: 9%</h4>
          </div>
        </div>
      </div>
      <!-- Inicio del Formulario y su Titulo -->
      <br>
      <div class="marg"><h3 class="brblank">Registrar Vendedor y Ventas</h3></div>
      <div class="centerAll">
        <form method="post">
          <h4 class="brblank">Nombre</h4>
          <input class="inputsPHP" type="text" id="Nom" Name="Nom">
          <h4 class="brblank">Call of duty</h4>
          <input class="inputsPHP" type="text" id="CanVenCod" Name="CanVenCod">
          <h4 class="brblank">Minecraft</h4>
          <input class="inputsPHP" type="text" id="CanVenMin" Name="CanVenMin">
          <h4 class="brblank">Fortnite</h4>
          <input class="inputsPHP" type="text" id="CanVenFor" Name="CanVenFor">
          <br>
          <br>
          <div class="btnAllign">
            <button class="btnPHP" type="submit" name="insertar"> Insertar<br>Datos</button>
            <button class="btnPHP" type="submit" name="mostrar"> Mostrar Tabla</button>
            <button class="btnPHP" type="submit" name="mostrarTodosTexto"> Mostrar modo texto </button>
          </div>
          <br>
          <br>
          <button class="btnPHP2" type="submit" name="mostrarTodos"> Mostrar Vendedor con Mayor Comisión </button>
          <br>
          <br>
        </form>
      </div>
    <?php
      if (isset($_POST['mostrar'])){
        if (is_countable($_SESSION['persona']===0)){ //si no hay personas
          echo "<p> No hay Personas </p>";
        }else {
          echo "<table class='table_style'>";
          echo "<tr>";
          echo "<th></th>";
          echo "<th class='cell_color'>Nombre</th>";
          echo "<th class='cell_color'>Call of duty</th>";
          echo "<th class='cell_color'>Minecraft</th>";
          echo "<th class='cell_color'>Fortnite</th>";
          echo "<th class='cell_color'>Total Ventas</th>";
          echo "<th class='cell_color'>Comision Call of Duty</th>";
          echo "<th class='cell_color'>Comision Minecraft</th>";
          echo "<th class='cell_color'>Comision Fortnite</th>";
          echo "<th class='cell_color'>Comision Total</th>";
          echo "<th class='cell_color'>Imagen del Juego</th>";
          echo "</tr>";
          foreach ($_SESSION['persona'] as $key => $value){ //recorre el array de personas
    ?>  
          <tr>
            <td></td>
            <td> <?php echo $value['Nom']; ?> </td>
            <td> <?php echo $value['CanVenCod']; ?> </td>
            <td> <?php echo $value['CanVenMin']; ?> </td>
            <td> <?php echo $value['CanVenFor']; ?> </td>
            <!-- total de ventas -->
            <td> <?php echo $value['TotalVentas']; ?> </td>
            <!-- comision ganada de Call of Duty que es del 6% -->
            <td> <?php echo $value['ComVenCod']; ?> </td>
            <!-- comision ganada de Minecraft que es del 4% -->
            <td> <?php echo $value['ComVenMin']; ?> </td>
            <!-- comision ganada de Fortnite que es del 9% -->
            <td> <?php echo $value['ComVenFor']; ?> </td>
            <!-- comision total -->
            <td> <?php echo $value['TotalComision']; ?> </td>
            <!-- Imagen del juego más vendido dependiendo de si Mayor es cod, si es min o si es for pondrá imagenes diferentes -->
            <td> <?php if ($value['Mayor'] == "cod"){
              echo "<img src='../resources/images/callofdutyCard.jpg' width='100' height='100'>";
            }else if ($value['Mayor'] == "min"){
              echo "<img src='../resources/images/minecraftCard.jpg' width='100' height='100'>";
            }else if ($value['Mayor'] == "for"){
              echo "<img src='../resources/images/fortniteCard.jpg' width='100' height='100'>";
            } 
            ?> </td>
          </tr>
          <?php  
          }
          echo "</table>";
          ?>
          <br>
          <?php
          if (vendedorMayorVentas($_SESSION['persona']) != "") {
            echo "<h4 style='font-size: 20px;'> El vendedor que generó más ventas es: ".vendedorMayorVentas($_SESSION['persona'])."</h4>"; //muestra el vendedor con mayor ventas
            echo "<h4 style='font-size: 20px;'> Ganando una comisión total de: ".vendedorMayorComision($_SESSION['persona'])."</h4>"; //muestra el vendedor con mayor comision
          }
        }
      }
      if (isset($_POST['mostrarTodos'])){ //si se presiona el boton mostrar todos
        if (is_countable($_SESSION['persona']===0)){
          echo "<p> No hay Personas </p>";
        }else {
          // si el return del vendedor no está vacio muestra el echo
          if (vendedorMayorVentas($_SESSION['persona']) != ""){
            echo "<h1 style='font-size: 30px;'> El vendedor que generó mayor comisión es: ".vendedorMayorComisionVentas($_SESSION['persona'])."</h1>"; //muestra el vendedor con mayor comision en base a Ventas
          } else {
            echo "<h1 style='font-size: 30px;'> No hay vendedor/personas </h1>"; //muestra el vendedor con mayor comision
          }
        }
      }
      if (isset($_POST['mostrarTodosTexto'])){ //si se presiona el boton mostrar modo Texto
        if (is_countable($_SESSION['persona']===0)){ //si no hay personas
          echo "<p> No hay Personas </p>";
        }else {
          //recorrer array y mostrar en echo valores de array para simular una especie de boleta
          foreach ($_SESSION['persona'] as $key => $value){
            echo "<h5> Nombre del Vendedor: ".$value['Nom']."</h5>";
            echo "<h5> Cantidad de Ventas del Call Of Duty: ".$value['CanVenCod']."</h5>";
            echo "<h5> Precio de Venta: $34500</h5>";
            echo "<h5> Comisión: 6%</h5>";
            echo "<h5> Cantidad Vendida sin comision: ".$value['GananciaCod']."</h5>";
            echo "<h5> Comisión Ganada: ".$value['ComVenCod']."</h5>";
            echo "<h5> Cantidad de Ventas del Minecraft: ".$value['CanVenMin']."</h5>";
            echo "<h5> Precio de Venta: $8800</h5>";
            echo "<h5> Comisión: 4%</h5>";
            echo "<h5> Cantidad Vendida sin comision: ".$value['GananciaMin']."</h5>";
            echo "<h5> Comisión Ganada: ".$value['ComVenMine']."</h5>";
            echo "<h5> Cantidad de Ventas del Fortnite: ".$value['CanVenFor']."</h5>";
            echo "<h5> Precio de Venta: $58200</h5>";
            echo "<h5> Comisión: 9%</h5>";
            echo "<h5> Cantidad Vendida sin comision: ".$value['GananciaFor']."</h5>";
            echo "<h5> Comisión Ganada: ".$value['ComVenFor']."</h5>";
            echo "<h5> ------------------------------------- </h5>";
          }
        }
      }
      ?>
  </div>
</body>
</html>