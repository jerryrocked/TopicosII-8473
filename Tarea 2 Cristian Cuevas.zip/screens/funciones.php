<?php
    function juegoGanoMayorComision($canVenCod,$canVenMin,$canVenFor) //Funcion para mostrar el juego más vendido, recibe la cantidad de ventas de cada juego
    {
      $canVenCod = $canVenCod;
      $canVenMin = $canVenMin;
      $canVenFor = $canVenFor;
      $juegoMasVendido = "";

      //calcula cual es mayor y cambiar juegoMasVendido por el nombre del juego que mas se vendio
      if ($canVenCod > $canVenMin && $canVenCod > $canVenFor) {
        $juegoMasVendido = "cod";
      } elseif ($canVenMin > $canVenCod && $canVenMin > $canVenFor) {
        $juegoMasVendido = "min";
      } elseif ($canVenFor > $canVenCod && $canVenFor > $canVenMin) {
        $juegoMasVendido = "for";
      }
      return $juegoMasVendido;
    }

    //funcion que recibe $_SESSION['persona'] y devuelve el nombre de la persona con mayores ventas
    function vendedorMayorVentas($persona)
    {
      //recorrer el array de personas
      foreach ($persona as $key => $value) {
        if ($value['TotalVentas'] > $mayorTotalVentas) { //si el total de ventas es mayor que el mayorTotalVentas
          $mayorTotalVentas = $value['TotalVentas']; //guardar el total de ventas en mayorTotalVentas
          $VendedorMayorVentas = $value['Nom']; //guardar el nombre del vendedor en VendedorMayorVentas
        }
      }
      return $VendedorMayorVentas; //devolver el nombre del vendedor con mayor ventas
    }

    //funcion que recibe $_SESSION['persona'] y devuelve el vendedor con mayores comisiones en base a las ventas
    function vendedorMayorComision($persona)
    {
      //recorrer el array de personas
      foreach ($persona as $key => $value) {
        //comparar nombre de cada persona para buscar el que tenga un mayor valor en TotalVentas
        if ($value["TotalVentas"] > $mayorTotalVentas2) {
          $mayorTotalVentas2 = $value['TotalVentas'];
          $vendedorMayorComision = $value["TotalComision"];
        }
      }
      return $vendedorMayorComision;
    }
    //funcion que recibe $_SESSION['persona'] y devuelve vendedor mayor comision
    function vendedorMayorComisionVentas($persona)
    {
      //recorrer el array de personas
      foreach ($persona as $key => $value) {
        //comparar nombre de cada persona para buscar el que tenga un mayor valor en TotalVentas
        if ($value["TotalComision"] > $mayorTotalComision) {
          $mayorTotalComision = $value['TotalComision'];
          $VendedorMayorVentas = $value['Nom'];
        }
      }
      return $VendedorMayorVentas;
    }
?>