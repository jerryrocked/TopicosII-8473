<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>El mundo de los video juegos</title>
    <link rel="stylesheet" href="styles/styles.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?
        family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="ImagenesPag/Imagenes/logos/ImagenLogo.png">
</head>
<body>
    <div class="navbar">
        <img class="logo_h1_maxscreen" src="ImagenesPag/Imagenes/logos/ImagenLogo.png">
        <div class="center">
            <img class="logo_h1_mobile" src="ImagenesPag/Imagenes/logos/ImagenLogo.png">
            <h1 id="h1_nav">El mundo de los video juegos</h1>
        </div>
        <nav id="nav">
            <ul>
                <li><a href="">Inicio</a></li>
                <li><a href="screens/login.php">Iniciar sesion</a></li>
            </ul>
        </nav>
    </div>
    <section class="section_inicio">
        <div class="intro_page">
            <h1 class="indexh1">GamerZone</h1>
            <p class="indexp">En esta tienda se venden todo tipo de videos juegos, ademas contamos con los 3 juegos mas vendidos por exelencia y en todas las plataformas disponibles, estos son Call of Duty, Fornite destacados por su modalidad BattleRoyale y Minecraft que es un juego que se caracteriza en su mundo abierto y rol.
            </p>

            <div>
              <center>
                <button class="btn-1"><a href="screens/login.php">Iniciar sesion.</a></button>
                </center>
            </div>
        </div>
    </section>

    <section class="section_estadsiticas-Roja-Feminina">
        <div id="Estadisticas-Roja-Femenina">

            <div class="col">
                <h2 class="title-card">¡Los Juegos mas vendidos!</h2>
                <div class="image">
                    <h4 id="title_image">Call of Duty</h4>

                    <a href="https://www.callofduty.com/es"><img class="image_img_no_up" src="ImagenesPag/Imagenes/CodImagen.jpg" alt="chilecard"></a>
                </div>
                <div class="image">
                    <h4 id="title_image">Fortnite</h4>
                    <a href="https://www.epicgames.com/fortnite/es-ES/home"><img class="image_img_no_up" src="ImagenesPag/Imagenes/FortniteImagen.jpg" alt="chilecard"></a>
                </div>
                <div class="image">
                    <h4 id="title_image">Minecraft</h4>
                    <a href="https://www.minecraft.net/es-es"><img class="image_img_no_up" src="ImagenesPag/Imagenes/MinecraftImagen.jpg" alt="chilecard"></a>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer">
        <h5 id="footer-left">El mundo de los video juegos 2022</h5>
    </footer>

</body>

</html>