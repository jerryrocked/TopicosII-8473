<?php @session_start();?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>El mundo de los video juegos</title>
    <link rel="stylesheet" href="../styles/styles.css">
    <!-- fuente Roboto de Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?
        family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="../ImagenesPag/Imagenes/Logo/ImagenLogo.png">
</head>
<body>
  <div class="container">
    <!--crea funcion en php llamado mayorComision($canVenCod,$canVenMin,$canVenFor) -->
    <?php
    function JuegoConMayorComision($canVenCod,$canVenMin,$canVenFor)
    {
      $canVenCod = $canVenCod;
      $canVenMin = $canVenMin;
      $canVenFor = $canVenFor;
      $juegoMasVendido = "";

      //calcula cual es mayor y cambiar juegoMasVendido por el nombre del juego que mas se vendio
      if ($canVenCod > $canVenMin && $canVenCod > $canVenFor) {
        $juegoMasVendido = "cod";
      } elseif ($canVenMin > $canVenCod && $canVenMin > $canVenFor) {
        $juegoMasVendido = "min";
      } elseif ($canVenFor > $canVenCod && $canVenFor > $canVenMin) {
        $juegoMasVendido = "for";
      }
      return $juegoMasVendido;
    }

    //funcion que recibe $_SESSION['Persona'] y devuelve el nombre de la Persona
    function mayorVentas($Persona)
    {
      //recorrer el array de Personas
      foreach ($Persona as $key => $value) {
        //comparar nombre de cada Persona en el array con los otros nombre del array y encontrar el que tenga mayor TotalVentas
        if ($value['TotalVentas'] > $mayorTotalVentas) {
          $mayorTotalVentas = $value['TotalVentas'];
          $VendedorMayorVentas = $value['Nom'];
        }
      }
      return $VendedorMayorVentas;
    }

    //funcion que recibe $_SESSION['Persona'] y devuelve el nombre de la Persona
    function mayorComision($Persona)
    {
      //recorrer el array de Personas
      foreach ($Persona as $key => $value) {
        //comparar nombre de cada Persona para buscar el que tenga un mayor Costo en TotalVentas
        if ($value["TotalVentas"] > $mayorTotalVentas2) {
          $mayorTotalVentas2 = $value['TotalVentas'];
          $vendedorMayorComision = $value["TotalComision"];
        }
      }
      return $vendedorMayorComision;
    }
    //funcion que recibe $_SESSION['Persona'] y devuelve vendedor mayor comision
    function mayorComision2($Persona)
    {
      //recorrer el array de Personas
      foreach ($Persona as $key => $value) {
        //comparar nombre de cada Persona para buscar el que tenga un mayor Costo en TotalVentas
        if ($value["TotalComision"] > $mayorTotalComision) {
          $mayorTotalComision = $value['TotalComision'];
          $VendedorMayorVentas = $value['Nom'];
        }
      }
      return $VendedorMayorVentas;
    }
    ?>

    <?php
      if (!isset($_SESSION['Persona'])){
        $_SESSION['Persona']=array();
      }
      if (isset($_POST['insertar'])) {
        $nom= $_POST['Nom'];
        $canVenCod= $_POST['CanVenCod'];
        $canVenMin= $_POST['CanVenMin'];
        $canVenFor= $_POST['CanVenFor'];
        if (empty($nom)||empty($canVenCod)||empty($canVenMin)||empty($canVenFor)) {
          echo "Rellena todos los Costoes";
          echo "<script>alert('Rellena todos los Costoes');</script>";
        } else if (!preg_match("/^[a-zA-Z ]*$/",$nom)) {
          echo "<script>alert('El Costo Nombre no puede contener caracteres ni numeros');</script>";
        } else if (!preg_match("/^[0-9]*$/",$canVenCod)||!preg_match("/^[0-9]*$/",$canVenMin)||!preg_match("/^[0-9]*$/",$canVenFor)) {
          echo "<script>alert('El Costo de cada producto no puede contener caracteres especiales ni numeros negativos o decimales');</script>";
        } else {
          $Persona = array(
            "Nom" => $nom,
            "CanVenCod" => $canVenCod,
            "CanVenMin" => $canVenMin,
            "CanVenFor" => $canVenFor,
            "ComVenCod" => $canVenCod*0.06*34500,
            "ComVenMin" => $canVenMin*0.04*8800,
            "ComVenFor" => $canVenFor*0.09*58200,
            "TotalVentas" => $canVenCod+$canVenMin+$canVenFor,
            "Mayor" => JuegoConMayorComision($canVenCod*0.06*34500,$canVenMin*0.04*8800,$canVenFor*0.09*58200),
            "TotalComision" => $canVenCod*0.06*34500+$canVenMin*0.04*8800+$canVenFor*0.09*58200,
            "GananciaCod" => $canVenCod*34500,
            "GananciaMin" => $canVenMin*8800,
            "GananciaFor" => $canVenFor*58200,
          );
          if (isset($_SESSION['Persona'][$nom])) {
            echo "Se ha modificado la Persona con el Nombre: ".$nom;
          }else{
            echo "<span style='color:white;'>";
            echo "Se ha registrado una Persona con Nombre: ".$nom;
            echo "</span>";
          }
          $_SESSION['Persona'][$nom]=$Persona;
          echo "<br>";
        }
      } else if (isset($_POST['vaciar'])){
        if (!isset($_POST['noms'])){
          echo "No hay Personas seleccionadas";
        }else{
          $noms=$_POST['noms'];
          print_r($noms);
          foreach ($_SESSION['Persona'] as $key => $value){
            if (in_array($key,$noms)){
              unset($_SESSION['Persona'][$key]);
            }
          }
          echo "Persona(s) Borrada(s) ";
        }
      }
      ?>
      <h3 class="brblank">Juegos Disponibles</h3>
      <div class="centeredImagenes">
        <div class="margins">
          <img class="marginsTopBottom" src="../ImagenesPag/Imagenes/CodImagen.jpg" alt="cod" width="100" height="100">
          <h4>Costo: $34500</h4>
          <h4>Comision: 6%</h4>
        </div>
        <div class="margins">
          <img class="marginsTopBottom" src="../ImagenesPag/Imagenes/MinecraftImagen.jpg" alt="min" width="100" height="100">
          <h4>Costo: $8800</h4>
          <h4>Comision: 4%</h4>
        </div>
        <div class="margins">
          <img class="marginsTopBottom" src="../ImagenesPag/Imagenes/FortniteImagen.jpg" alt="for" width="100" height="100">
          <h4>Costo: $58200</h4>
          <h4>Comision: 9%</h4>
        </div>
      </div>
      
      <br>
      <div class="marg"><h3 class="brblank">Registra Vendedor y Ventas</h3></div>
      <form method="post">
        <h4 class="brblank">NOMBRE</h4>
        <input type="text" id="Nom" Name="Nom">
        <h4 class="brblank">Call of dutty</h4>
        <input type="text" id="CanVenCod" Name="CanVenCod">
        <h4 class="brblank">Minecraft</h4>
        <input type="text" id="CanVenMin" Name="CanVenMin">
        <h4 class="brblank">Fortnite</h4>
        <input type="text" id="CanVenFor" Name="CanVenFor">
        <br>
        <br>
        <button type="submit" name="insertar"> Insertar </button>
        <button type="submit" name="mostrar"> Mostrar Tabla</button>
        <br>
        <button type="submit" name="mostrarTodos"> Mostrar Vendedor con Mayor Ventas </button>
        <br>
        <button type="submit" name="mostrarTodosTexto"> Mostrar modo Texto </button>
        <br>
        <br>
    <?php
      if (isset($_POST['mostrar'])){
        if (is_countable($_SESSION['Persona']===0)){
          echo "<p> No hay Personas </p>";
        }else {
          echo "<table border=1>";
          echo "<tr>";
          echo "<th></th>";
          echo "<th>Nombre</th>";
          echo "<th>Call of dutty</th>";
          echo "<th>Minecraft</th>";
          echo "<th>Fortnite</th>";
          echo "<th>Total Ventas</th>";
          echo "<th>Comision Call of dutty</th>";
          echo "<th>Comision Minecraft</th>";
          echo "<th>Comision Fortnite</th>";
          echo "<th>Comision Total</th>";
          echo "<th>Imagen del Juego</th>";
          echo "</tr>";
          foreach ($_SESSION['Persona'] as $key => $value){
    ?>  
          <tr>
            <td></td>
            <td> <?php echo $value['Nom']; ?> </td>
            <td> <?php echo $value['CanVenCod']; ?> </td>
            <td> <?php echo $value['CanVenMin']; ?> </td>
            <td> <?php echo $value['CanVenFor']; ?> </td>
            <td> <?php echo $value['TotalVentas']; ?> </td>
            <td> <?php echo $value['ComVenCod']; ?> </td>
            <td> <?php echo $value['ComVenMin']; ?> </td>
            <td> <?php echo $value['ComVenFor']; ?> </td>
            <td> <?php echo $value['TotalComision']; ?> </td>
            <td> <?php if ($value['Mayor'] == "cod"){
              echo "<img src='../ImagenesPag/Imagenes/CodImagen.jpg' width='100' height='100'>";
            }else if ($value['Mayor'] == "min"){
              echo "<img src='../ImagenesPag/Imagenes/MinecraftImagen.jpg' width='100' height='100'>";
            }else if ($value['Mayor'] == "for"){
              echo "<img src='../ImagenesPag/Imagenes/FortniteImagen.jpg' width='100' height='100'>";
            } 
            ?> </td>
          </tr>
          <?php  
          }
          echo "</table>";
          ?>
          <?php 
          echo "<h4> El vendedor que genero mas ventas es: ".mayorVentas($_SESSION['Persona'])."</h4>";
          echo "<h4> Ganando una Comision total de: ".mayorComision($_SESSION['Persona'])."</h4>";
        }
      } if (isset($_POST['mostrarTodos'])){
        if (is_countable($_SESSION['Persona']===0)){
          echo "<p> No hay Personas </p>";
        }else {
          echo "<h1> El vendedor con mayor Comision es: ".mayorComision2($_SESSION['Persona'])."</h1>";
        }
      } if (isset($_POST['mostrarTodosTexto'])){
        if (is_countable($_SESSION['Persona']===0)){
          echo "<p> No hay Personas </p>";
        }else {
          foreach ($_SESSION['Persona'] as $key => $value){
            echo "<h5> Nombre del Vendedor: ".$value['Nom']."</h5>";
            echo "<h5> Cantidad de Ventas del Call Of dutty: ".$value['CanVenCod']."</h5>";
            echo "<h5> Precio de Venta: $34500</h5>";
            echo "<h5> Comision: 6%</h5>";
            echo "<h5> Cantidad Vendida sin comision: ".$value['GananciaCod']."</h5>";
            echo "<h5> Comision Ganada: ".$value['ComVenCod']."</h5>";
            echo "<h5> Cantidad de Ventas del Minecraft: ".$value['CanVenMin']."</h5>";
            echo "<h5> Precio de Venta: $8800</h5>";
            echo "<h5> Comision: 4%</h5>";
            echo "<h5> Cantidad Vendida sin comision: ".$value['GananciaMin']."</h5>";
            echo "<h5> Comision Ganada: ".$value['ComVenMine']."</h5>";
            echo "<h5> Cantidad de Ventas del Fortnite: ".$value['CanVenFor']."</h5>";
            echo "<h5> Precio de Venta: $58200</h5>";
            echo "<h5> Comision: 9%</h5>";
            echo "<h5> Cantidad Vendida sin comision: ".$value['GananciaFor']."</h5>";
            echo "<h5> Comision Ganada: ".$value['ComVenFor']."</h5>";
            echo "<h5> ________________________________________</h5>";
          }
        }
      }
          ?>
      </form>
  </div>
</body>
</html>