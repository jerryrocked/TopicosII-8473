<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>El mundo de los video juegos</title>
    <link rel="stylesheet" href="../styles/styles.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?
        family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="../ImagenesPag/Imagenes/logos/ImagenLogo.png">
</head>
<body>
    <div class="navbar">
        <img class="logo_h1_maxscreen" src="../ImagenesPag/Imagenes/logos/ImagenLogo.png">
                <div class="center">
            <img class="logo_h1_mobile" src="../ImagenesPag/Imagenes/logos/ImagenLogo.png">
            <h1 id="h1_nav">El mundo de los video juegos</h1>
        </div>
        <nav id="nav">
            <ul>
                <li><a href="../index.php">Inicio</a></li>
                <li><a href="login.php">Iniciar sesion</a></li>
            </ul>
        </nav>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                <div class="card card-signin my-5">
                    <div class="card-body">
                        <h4 class="h4login">Iniciar Sesion</h4>
                        <form class="form-signin" action="programaVendedor.php" method="post">
                            <div class="form-label-group">
                                <input type="text" id="inputEmail" class="form-control" placeholder="Usuario" required autofocus name="usuario">
                                <label class="h5login" for="inputEmail">Usuario</label>
                            </div>
                            <div class="form-label-group">
                                <input type="password" id="inputPassword" class="form-control" placeholder="Clave" required name="password">
                                <label class="h5login" for="inputPassword">Clave</label>
                            </div>
                            <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">Iniciar Sesion</button>
                        </form>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</body>







