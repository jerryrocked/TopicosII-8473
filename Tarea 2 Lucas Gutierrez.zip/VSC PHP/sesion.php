<!doctype html>
<html lang = "es">
  <head>
  <title>php vendedores</title>
  <link rel= "stylesheet" type = "text/css" href ="css/dphp.css"
</head>
<boby>

<?php 
require_once "sesion.php";
session_start();
$permitidos = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
$p1 = 34500;
$p2 = 8800;
$p3 = 58200;
$_SESSION["listacod"] = array("juan" => 25, "mateo" => 10 , "franco" => 15);
$_SESSION["listamine"] = array("juan" => 30,"mateo" => 5, "franco" => 20);
$_SESSION["listaforn"] = array("juan" => 45, "mateo" => 3, "franco" => 25);
$vendedor = $_REQUEST["vendedor"];
$juego = $_REQUEST["juego"];
$unidades = $_REQUEST["unidades"];
$opcion = $_REQUEST["opcion"];
$vof = 0;
$aux = 0;
$len = 0;



if ($opcion == "ingresar"){
// se asegura que los datos ingresados esten correctos.
  for ($i=0; $i<strlen($vendedor); $i++){
    if (strpos($permitidos, substr($vendedor,$i,1))==false){
       echo " El nombre $vendedor no es valido, por favor ingrese solo letras (mayusculas o minusculas)<br>";
       return false;
    }
 }

 if ($unidades <= 0){
    echo " El numero de unidades es negativo o esta vacio $unidades por lo tanto no es valido, por favor intente numeros validos<br>";
    return false;

 }
 else {
  for ($i=0; $i<strlen($unidades); $i++){
    if (strpos($permitidos, substr($unidades,$i,1))==true){
       echo "El numero de unidades $unidades no es valido, por favor intente numeros validos<br>";
       return false;
    }
 }
}
// comprueba si esta creado el vendedor en la lista.
  foreach ($_SESSION["listacod"] as $id => $un) {
    if ($id == $vendedor){
      $vof = 1;
      
    }
  }
  
  foreach ($_SESSION["listamine"] as $id => $un) {
    if ($id == $vendedor){
      $vof = 1;
    }
  }
  
  foreach ($_SESSION["listaforn"] as $id => $un) {
    if ($id == $vendedor){
     $vof = 1;
    }
  }
  // si el vendedor no esta en la lista sera agregado en todas las listas su nombre y las unidades seran agregadas correspondientemente.
  if ($vof == 0 && $juego == "call_of_duty"){
    $_SESSION["listacod"][$vendedor] = $unidades;
    $_SESSION["listamine"][$vendedor] = 0;
    $_SESSION["listaforn"][$vendedor] = 0;
  }
  else if ($vof == 0 && $juego == "minecraft"){
    $_SESSION["listamine"][$vendedor] = $unidades;
    $_SESSION["listacod"][$vendedor] = 0;
    $_SESSION["listaforn"][$vendedor] = 0;
  }
  else if ($vof == 0 && $juego == "fornite"){
    $_SESSION["listaforn"][$vendedor] = $unidades;  
    $_SESSION["listacod"][$vendedor] = 0;
    $_SESSION["listamine"][$vendedor] = 0;
  }
  
  
  // si ya esta en la lista solamente se le agregara las unidades a la lista correspondiente.
  if ($vof == 1 && $juego == "call_of_duty"){
    $len = count($_SESSION["listacod"]);
    foreach ($_SESSION["listacod"] as $id => [$un]) {
      if($id == $vendedor){
        $_SESSION["listacod"][$id] =$_SESSION["listacod"][$id]+ $unidades;  
        }
      }
  }
           
  elseif ($vof == 1 && $juego == "minecraft"){
    $len = count($_SESSION["listamine"]);
    foreach ($_SESSION["listamine"] as $id => [$un]) {
      if($id == $vendedor){
        $_SESSION["listamine"][$id] =$_SESSION["listamine"][$id]+ $unidades;  
        }
      }
  }
  
  elseif ($vof == 1 && $juego == "fornite"){
    $len = count($_SESSION["listaforn"]);
    foreach ($_SESSION["listaforn"] as $id => [$un]) {
      if($id == $vendedor){
        $_SESSION["listaforn"][$id] = 5;  
        }
      }
  }
  echo"Los datos <br> Nombre: $vendedor <br>Juego: $juego <br>Cantidad: $unidades<br> fueron ingresados correctamente";

  $mayor_total = 0;
  $cantfilas = count($_SESSION["listacod"]);
  $cantcolumnas = 1;
  $clave = "";
  $si = 0;
  $contador = 0 ;
  $n = 0;
  echo "<table border =2>";
  for ($fila=0;$fila<=$cantfilas; $fila++){
    echo "<tr>";
    for($columna=1;$columna<=$cantcolumnas; $columna++){
      if ($si == 0){
        echo "<td> Nombre </td> <td> Unidades COD </td> <td> Unidades MIN </td> <td> Unidades FOR </td> <td> Ventas COD </td> <td> Ventas MIN </td> <td> Ventas FOR </td> <td> Total ventas </td> <td> Comision COD </td> <td> Comision MIN </td> <td> Comision FOR </td> <td> Total Comision </td>";
        $si++;
    }
      else{
         foreach ($_SESSION["listacod"] as $id1 => $un1) {
           if ($contador == $n){
             $clave = $id1;
           }
           $n++;

            if ($clave == $id1){
              echo"<td> $id1 </td> <td> $un1 </td>";
              $a = $un1*$p1;
            }
          }  
          foreach ($_SESSION["listamine"] as $id2 => $un2) {
            if ($clave == $id2){
              echo"<td> $un2 </td>";
              $b = $un2*$p2;

            }
          }
          foreach ($_SESSION["listaforn"] as $id3 => $un3) {
              if ($clave == $id3){
                echo"<td> $un3 </td>";
                $c = $un3*$p3;
 
              }
            }
          $d = $a+$b+$c;
          $e = $a*0.06;
          $f = $b*0.04;
          $g = $c*0.09;
          $h = $e+$f+$g;
          

          if ($h > $mayor_total){
            $mayor_total = $h;
            $indicador = $contador;

          } 
          echo "<td> $a </td> <td> $b </td> <td> $c </td> <td> $d </td> <td> $e  </td> <td> $f </td> <td> $g </td> <td> $h </td>";
          echo"</tr>";
          $contador++;
          $n = 0;
          $clave = "";




            
        



    }
    }
  }
  echo"</table>";





}
// Recorre las listas buscando el identificador, si lo encuentra lo imprime por pantalla y aumenta el contador para que busque el siguiente dato.


else if ($opcion == "tabla"){
  $mayor_total = 0;
  $cantfilas = count($_SESSION["listacod"]);
  $cantcolumnas = 1;
  $clave = "";
  $si = 0;
  $contador = 0 ;
  $n = 0;
  echo "<table border =2>";
  for ($fila=0;$fila<=$cantfilas; $fila++){
    echo "<tr>";
    for($columna=1;$columna<=$cantcolumnas; $columna++){
      if ($si == 0){
        echo "<td> Nombre </td> <td> Unidades COD </td> <td> Unidades MIN </td> <td> Unidades FOR </td> <td> Ventas COD </td> <td> Ventas MIN </td> <td> Ventas FOR </td> <td> Total ventas </td> <td> Comision COD </td> <td> Comision MIN </td> <td> Comision FOR </td> <td> Total Comision </td>";
        $si++;
    }
      else{
         foreach ($_SESSION["listacod"] as $id1 => $un1) {
           if ($contador == $n){
             $clave = $id1;
           }
           $n++;

            if ($clave == $id1){
              echo"<td> $id1 </td> <td> $un1 </td>";
              $a = $un1*$p1;
            }
          }  
          foreach ($_SESSION["listamine"] as $id2 => $un2) {
            if ($clave == $id2){
              echo"<td> $un2 </td>";
              $b = $un2*$p2;

            }
          }
          foreach ($_SESSION["listaforn"] as $id3 => $un3) {
              if ($clave == $id3){
                echo"<td> $un3 </td>";
                $c = $un3*$p3;
 
              }
            }
          $d = $a+$b+$c;
          $e = $a*0.06;
          $f = $b*0.04;
          $g = $c*0.09;
          $h = $e+$f+$g;
          

          if ($h > $mayor_total){
            $mayor_total = $h;
            $indicador = $contador;

          } 
          echo "<td> $a </td> <td> $b </td> <td> $c </td> <td> $d </td> <td> $e  </td> <td> $f </td> <td> $g </td> <td> $h </td>";
          echo"</tr>";
          $contador++;
          $n = 0;
          $clave = "";




            
        



    }
    }
  }
  echo"</table>";


    

}
// Recopila informacion del vendedor que mas dinero genero y posteriormente con la posicion del vendedor se recorre la lista buscandolo.
else if ($opcion == "destacado"){

  $cantfilas = count($_SESSION["listacod"]);
  $cantcolumnas = 1;
  $clave = "";
  $si = 0;
  $contador = 0 ;
  $n = 0;
  $mayor_total = 0;
  $indicador = 0;
  for ($fila=0;$fila<=$cantfilas; $fila++){
    for($columna=1;$columna<=$cantcolumnas; $columna++){
      if ($si == 0){
        $si++;
    }
      else{
         foreach ($_SESSION["listacod"] as $id1 => $un1) {
           if ($contador == $n){
             $clave = $id1;
           }
           $n++;

            if ($clave == $id1){
              $a = $un1*$p1;
            }
          }  
          foreach ($_SESSION["listamine"] as $id2 => $un2) {
            if ($clave == $id2){
              $b = $un2*$p2;

            }
          }
          foreach ($_SESSION["listaforn"] as $id3 => $un3) {
              if ($clave == $id3){
                $c = $un3*$p3;
 
              }
            }
          $d = $a+$b+$c;
          $e = $a*0.06;
          $f = $b*0.04;
          $g = $c*0.09;
          $h = $e+$f+$g;
          

          if ($h > $mayor_total){
            $mayor_total = $h;
            $indicador = $contador;

          } 
          $contador++;
          $n = 0;
          $clave = "";

    }
    }

  }


  $cantfilas = 1;
  $cantcolumnas = 1;
  $clave = "";
  $si = 0;
  $contador = 0 ;
  $n = 0;
  echo "<table border =2>";
  for ($fila=0;$fila<=$cantfilas; $fila++){
    echo "<tr>";
    for($columna=1;$columna<=$cantcolumnas; $columna++){
      if ($si == 0){
        echo "<td> Nombre </td> <td> Unidades COD </td> <td> Unidades MIN </td> <td> Unidades FOR </td> <td> Ventas COD </td> <td> Ventas MIN </td> <td> Ventas FOR </td> <td> Total ventas </td> <td> Comision COD </td> <td> Comision MIN </td> <td> Comision FOR </td> <td> Total Comision </td>";
        $si++;
    }
      else{
         foreach ($_SESSION["listacod"] as $id1 => $un1) {
           if ($indicador == $n){
             $clave = $id1;
           }
           $n++;

            if ($clave == $id1){
              echo"<td> $id1 </td> <td> $un1 </td>";
              $a = $un1*$p1;
            }
          }  
          foreach ($_SESSION["listamine"] as $id2 => $un2) {
            if ($clave == $id2){
              echo"<td> $un2 </td>";
              $b = $un2*$p2;

            }
          }
          foreach ($_SESSION["listaforn"] as $id3 => $un3) {
              if ($clave == $id3){
                echo"<td> $un3 </td>";
                $c = $un3*$p3;
 
              }
            }
          $d = $a+$b+$c;
          $e = $a*0.06;
          $f = $b*0.04;
          $g = $c*0.09;
          $h = $e+$f+$g;
           
          echo "<td> $a </td> <td> $b </td> <td> $c </td> <td> $d </td> <td> $e  </td> <td> $f </td> <td> $g </td> <td> $h </td>";
          echo"</tr>";
          $contador++;
          $n = 0;
          $clave = "";




            
        



    }
    }
  }
  echo"</table>";


  





  


}





?>