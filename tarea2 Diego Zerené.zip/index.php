
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1">
    <title>Tu portal de juegos</title>
    <link rel="stylesheet" href="css/styles2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <header>
        <div class="contenedor">
            <img id="imagen" src="images/control.png" width="50" height="50" >
            <h1>  Tienda gaming</h1>
            <!--Se crea la barra de menú mediante un checkbox-->
            <input type="checkbox" id="menu">
            <label for="menu"> <img src="images/menu.png" width="45"  height="25"></label>  
            <nav class="barra">
                <a href="index.php">Inicio</a> 
                <a href="vendedor.php">Vender productos</a>        
            </nav>
        </div>
    </header>
        <div class="banner">
        </div>
    
        <div id="juegos">
            <img  src="images/cod.jpg" alt="">
            <div class="image__overlay image__overlay--blur">
                <div class="image__tittle">Call of duty</div>
                <p class="image__description">
                    $34.500
                </p>
            </div>
            
            <img src="images/fortnite.jpg"  alt="">
            <div class="image__overlay2 image__overlay2--blur">
                <div class="image__tittle2">Fortnite</div>
                <p class="image__description2">
                    $58.200
                </p>
            </div>
            <img src="images/minecraft.jpg"  alt="">
            <div class="image__overlay3 image__overlay3--blur">
                <div class="image__tittle3">Minecraft</div>
                <p class="image__description3">
                    $8.800
                </p>
            </div>

        </div>
    
        <div id="texto">
            <h3>Bienvenido</h3>
            <p>Aquí podrás organizar las ventas de videojuegos de nuestra compañía</p>
            <div>
                <!--Se crea un botón que redireccionará al cuadro de vendedores-->
                <button onclick="location.href='vendedor.php'" type="button" >Vender</button>
            </div>
        </div>     
        <footer>
        <div class="contenedor1">


            <div class="caja">
                <h2>Tienda gaming</h2>
                <p>Creada en 2022.</p>
            
            </div>

            <div class="caja">
                <h2>Nuestras redes sociales:</h2>
                <div class="sociales">
                    <li><a class="fab fa-facebook-f" style="color:#ffffff;" ></a></li>
                    <li><a class="fab fa-instagram"  style="color:#ffffff;" ></a></li>
                    <li><a class="fab fa-youtube"  style="color:#ffffff;" ></a></li>
                    <li><a class="fab fa-twitter"  style="color:#ffffff;" ></a></li>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>