<?php @session_start();?>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1">
    <title>Venta</title>
    <link rel="stylesheet" href="css/styles2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
 
    <header>
        <div class="contenedor">
            <img id="imagen" src="images/control.png" width="50" height="50" >
            <h1>  Tienda gaming</h1>
            <!--Se crea la barra de menú mediante un checkbox-->
            <input type="checkbox" id="menu">
            <label for="menu"> <img src="images/menu.png" width="45"  height="25"></label>  
            <nav class="barra">
                <a href="index.php">Inicio</a> 
                <a href="vendedor.php">Vender productos</a>        
            </nav>
        </div>
    </header>
            <div class="banner">
    <?php
    if (!isset($_SESSION['persona'])){
      $_SESSION['persona']= array();
    }
    if (isset($_POST['insertar'])){
      $nom=$_POST['Nom'];
      $cod=$_POST['Cod'];
			$min=$_POST['Min'];
			$for=$_POST['For'];
      if (empty($nom)||empty($cod)|| empty($min) || empty($for)){
        echo "Rellena todos los campos";
      }
      if (empty($nom) || $cod<0 || $min<0 || $for<0){
        echo "No se aceptan negativos";
      }else {
				$ccod=($cod*34500)*0.06;
				$cmin=($min*8800)*0.04;
				$cfor=($for*58200)*0.09;
				$total= $ccod+$cmin+$cfor;
        $persona = array(
          "nom" => $nom,
          "cod" => $cod,
					"min" => $min,
					"for" => $for,
					"totalv" => $cod+$min+$for,
					"ccod" => $ccod,
					"cmin" => $cmin,
					"cfor" => $cfor,
					"ctotal" => $total
        );
        if (isset($_SESSION['persona'][$nom])){
          echo "Se ha modificado la Persona ";
        }else {
        }
        $_SESSION['persona'][$nom]=$persona;
      }
        
    }

?>
<form method="post">
<table id='tabla'>
  <th>Nombre
  <input type="text" id="Nom" name="Nom"/></th>
  <th>Ventas COD
  <input type="text" id="Cod" name="Cod"/>
	<br>Ventas MIN
  <input type="text" id="Min" name="Min"/>
	<br>Ventas FOR
  <input type="text" id="For" name="For"/></th>

</table>
<button type="submit" name="insertar" >Insertar </button>
<button type="submit" name="mostrar" >Mostrar </button>
<button type="submit" name="comisionmayor" >Mayor Comisión </button>
<?php 
  if (isset($_POST['mostrar'])){
    if (count($_SESSION['persona'])===0){
      echo "<p> No hay Personas</p>";
    }else {
      echo "<table id='tabla' border=1>";
      echo "<tr>";
      echo "<th style='width:100px'>NOMBRE</th>";
      echo "<th style='width:100px'>Cantidad ventas COD</th>";
			echo "<th style='width:100px'>Cantidad ventas MIN</th>";
			echo "<th style='width:100px'>Cantidad ventas FOR</th>";
			echo "<th style='width:100px'>Total ventas </th>";
			echo "<th style='width:100px'>Comision ventas COD</th>";
			echo "<th style='width:100px'>Comision ventas MIN</th>";
			echo "<th style='width:100px'>Comision ventas FOR</th>";
			echo "<th style='width:100px'>Comision total ventas </th>";
      echo "</tr>";
      foreach ($_SESSION['persona'] as $key => $value){
  ?>  
          <table id="tabla">
      <tr >
        <td style="width:100px"><?php echo $value['nom']; ?></td>
        <td style='width:100px'><?php echo $value['cod']; ?></td>
				<td style='width:100px'><?php echo $value['min']; ?></td>
				<td style='width:100px'><?php echo $value['for']; ?></td>
				<td style='width:100px'><?php echo $value['totalv']; ?></td>
				<td style='width:100px'><?php echo "$".$value['ccod']; ?></td>
				<td style='width:100px'><?php echo "$".$value['cmin']; ?></td>
				<td style='width:100px'><?php echo "$".$value['cfor']; ?></td>
				<td style='width:100px'><?php echo "$".$value['ctotal']; ?></td>
      </tr>
          </table>
  <?php
      }
      echo "</table>";
    }
  }
  if (isset($_POST['comisionmayor'])){
      
        $mayor=0;
        foreach ($_SESSION['persona'] as $key => $value){
            if ($mayor<$value['ctotal']){
                $mayor=$value['ctotal'];
                $empleado=$value['nom'];
            }
        }
    echo $empleado;
    echo " ".$mayor;
  }
   ?>   
</form> 
</div>
        <footer>
        <div class="contenedor1">
            <div class="caja">
                <h2>Tienda gaming</h2>
                <p>Creada en 2022.</p>          
            </div>
            <div class="caja">
                <h2>Nuestras redes sociales:</h2>
                <div class="sociales">
                    <li><a class="fab fa-facebook-f" style="color:#ffffff;" ></a></li>
                    <li><a class="fab fa-instagram"  style="color:#ffffff;" ></a></li>
                    <li><a class="fab fa-youtube"  style="color:#ffffff;" ></a></li>
                    <li><a class="fab fa-twitter"  style="color:#ffffff;" ></a></li>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>