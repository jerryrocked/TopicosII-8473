<?php session_start(); ?>
<html>
  <head>
    <title>Tabla de vendedores</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/styles.css">
  </head>
    
  <body>
    <?php
        if (!isset($_SESSION['persona'])){
            $_SESSION['persona'] = array();   
        }
        
        if (isset($_POST['insertar'])){
            $nom = $_POST['Nom'];
            $venCod = $_POST['venCod'];
            $venMin = $_POST['venMin'];
            $venFor = $_POST['venFor'];
            
            if (empty($nom)||empty($venCod)||empty($venMin)||empty($venFor)){
                echo "Rellena todos los campos.";

            #Condicion para que el usuario ingrese letras en el nombre
            }else if(ctype_alpha($nom) == false){
                echo "Solo letras en el nombre";
            
            #Condicion para que el usuario ingrese numeros enteros y positivos
            }else if(false == ctype_digit($venCod) || 0 > intval($venCod)||
                     false == ctype_digit($venMin) || 0 > intval($venMin)||
                     false == ctype_digit($venFor) || 0 > intval($venFor)){
                         echo "Solo numero enteros y positivos";
            }else{
                #Suma de todas las totalVentas
                $totalVentas = $venCod*34500 + $venMin*8800 + $venFor*58200;
                #Comisiones de cada juego
                $comiCod = $venCod*2070;
                $comiMin = $venMin*352;
                $comiFor = $venFor*5238;
                #Suma de las comisiones
                $totalComi = $comiCod+$comiMin+$comiFor;
                
                $persona = array(
                    "Nom" => $nom,
                    "venCod" => $venCod,
                    "venMin" => $venMin,
                    "venFor" => $venFor,
                    "totalVentas" => $totalVentas,
                    
                    "comiCod" => $comiCod,
                    "comiMin" => $comiMin,
                    "comiFor" => $comiFor,
                    "totalComi" => $totalComi,
                );
                if (isset($_SESSION['persona'][$nom])){
                    echo "Se ha modificado la persona con el nombre: ".$nom;
                }else{
                    echo "Se ha registrado la persona: ";
                }
                $_SESSION['persona'][$nom]=$persona;
                #print_r($_SESSION['persona']);
            }
        }
    ?>
    <form method="post">
        <div id="inputs" align="center">
            <br>NOMBRE DEL VENDEDOR
            <input type="text" id="Nom" name="Nom">
            <br>VENTAS CALL OF DUTY
            <input type="text" id="venCod" name="venCod">
            <br>VENTAS MINECRAFT
            <input type="text" id="venMin" name="venMin">
            <br>VENTAS FORTNITE
            <input type="text" id="venFor" name="venFor">
            <br>
            <button type="submit" name="insertar"> Insertar </button>
            <button type="submit" name="mostrar"> Mostrar </button>
            <button type="submit" name="vendedor"> Vendedor con mayor comisión </button>
            
            <button type="submit"><a href="Videojuegos.html">Pagina principal</a></button>
        </div>

    <?php
            if(isset($_POST['vendedor'])){
                if (count($_SESSION['persona'])===0){
				    echo "<p> No hay Personas </p>";
			    }else{
                    $mayorvendedor = array();
                    foreach ($_SESSION['persona'] as $key => $value){
                        array_push($mayorvendedor, $value['totalVentas']);
                    }
                    
                    echo "<table border=1>";
                    echo "<tr>";
                    echo "<th>Nombre Vendedor</th>";
                    echo "<th>Cantidad Ventas COD</th>";
                    echo "<th>Cantidad Ventas MIN</th>";
                    echo "<th>Cantidad Ventas FOR</th>";
                    echo "<th>Total Ventas</th>";
                    echo "<th>Comision Call of Dutty</th>";
                    echo "<th>Comision Minecraft</th>";
                    echo "<th>Comision Fortnite</th>";
                    echo "<th>Comision Total</th>";
                    echo "<th colspan=3>Imagen de los juego</th>";
                    echo "</tr>";
                    foreach ($_SESSION['persona'] as $key => $value){
                        if (max($mayorvendedor) == $value['totalVentas']){?>
                            <tr border=>
                            <td> <b> <?php echo $value['Nom']; ?> </td>
                                
                            <td> <b> <?php echo $value['venCod']; ?> </td>
                            <td> <b> <?php echo $value['venMin']; ?> </td>
                            <td> <b> <?php echo $value['venFor']; ?> </td>
                            <td> <b> <?php echo $value['totalVentas']; ?> </td>
                                
                            <td> <b> <?php echo $value['comiCod']; ?> </td>
                            <td> <b> <?php echo $value['comiMin']; ?> </td>
                            <td> <b> <?php echo $value['comiFor']; ?> </td>
                            <td> <b> <?php echo $value['totalComi']; ?> </td>
                            <td>
                                <img src="img/cod.jpg" id="imgCod">
                                <p>Precio = $34500
                                <p> <?php echo "Total totalVentas = $",$value['venCod']*34500; ?> </p>
                                <p> <?php echo "Total comisión= $",$value['totalComi']; ?> </p>
                            </td>
                            <td>
                                <img src="img/minecraft.jpg" id="imgMine">
                                <p>Precio = $8800
                                <p> <?php echo "Total totalVentas = $",$value['venMin']*8800; ?> </p>
                                <p> <?php echo "Total comisión= $",$value['totalComi']; ?> </p>
                            </td>
                            <td>
                                <img src="img/fortnite.jpg" id="imgFort">
                                <p>Precio = $58200
                                <p> <?php echo "Total totalVentas = $",$value['venFor']*58200; ?> </p>
                                <p> <?php echo "Total comisión= $",$value['totalComi']; ?> </p>
                            </td>
                            </tr>
    <?php  
            
    echo "</table>";
                        }
                    }
                }
            }
    ?>
    <?php
        
        if (isset($_POST['mostrar'])){
			if (count($_SESSION['persona'])===0){
				echo "<p> No hay Personas </p>";
			}else {
            echo "<table border=1>";
            echo "<tr>";
            echo "<th>Nombre Vendedor</th>";
            echo "<th>Cantidad Ventas COD</th>";
            echo "<th>Cantidad Ventas MIN</th>";
            echo "<th>Cantidad Ventas FOR</th>";
            echo "<th>Total Ventas</th>";
            echo "<th>Comision Call of Dutty</th>";
            echo "<th>Comision Minecraft</th>";
            echo "<th>Comision Fortnite</th>";
            echo "<th>Comision Total</th>";
            echo "<th colspan=3>Imagen de los juego</th>";
            echo "</tr>";
            foreach ($_SESSION['persona'] as $key => $value){
    ?>  
        <tr>
        <!--<td><input type="checkbox" name="noms[]" value= "<?php echo $key; ?>"></td> -->
        <td> <?php echo $value['Nom']; ?> </td>
            
        <td> <?php echo $value['venCod']; ?> </td>
        <td> <?php echo $value['venMin']; ?> </td>
        <td> <?php echo $value['venFor']; ?> </td>
        <td> <?php echo $value['totalVentas']; ?> </td>
            
        <td> <?php echo $value['comiCod']; ?> </td>
        <td> <?php echo $value['comiMin']; ?> </td>
        <td> <?php echo $value['comiFor']; ?> </td>
        <td> <?php echo $value['totalComi']; ?> </td>
        <td>
            <img src="img/cod.jpg" id="imgCod" >
            <p>Precio = $34500
            <p> <?php echo "Total totalVentas = $",$value['venCod']*34500; ?> </p>
            <p> <?php echo "Total comisión= $",$value['totalComi']; ?> </p>
        </td>
        <td>
            <img src="img/minecraft.jpg" id="imgMine">
            <p>Precio = $8800
            <p> <?php echo "Total totalVentas = $",$value['venMin']*8800; ?> </p>
            <p> <?php echo "Total comisión= $",$value['totalComi']; ?> </p>
        </td>
        <td>
            <img src="img/fortnite.jpg" id="imgFort">
            <p>Precio = $58200
            <p> <?php echo "Total totalVentas = $",$value['venFor']*58200; ?> </p>
            <p> <?php echo "Total comisión= $",$value['totalComi']; ?> </p>
        </td>
        </tr>
    <?php  
            }
    echo "</table>";
            }    
        }
    ?>
    
    </body>
</html>